class Computer < ApplicationRecord
  has_many :games
end
