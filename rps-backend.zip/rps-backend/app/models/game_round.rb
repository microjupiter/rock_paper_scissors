class GameRound < ApplicationRecord
  belongs_to :game
end
