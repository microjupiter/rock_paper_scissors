require "test_helper"

class GameRoundTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
